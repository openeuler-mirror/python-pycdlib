PyCdlib is a pure python library to parse, write (master), and create ISO9660 files, suitable for writing to a CD or USB.

The original ISO9660 (including ISO9660-1999) specification is supported, as well the El Torito, Joliet, Rock Ridge, and UDF extensions.

Please see https://clalancette.github.io/pycdlib/ for much more documentation.
